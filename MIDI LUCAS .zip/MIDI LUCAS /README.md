# Evening-Sun-MC6
An Arduino based Midi Controller with 6 Buttons and a 4 line LCD Display 

All relevant information can be found here:
https://line6.com/support/topic/61937-evening-sun-mc6-diy-midi-controller-for-hx-stomp-and-others/

and here

https://www.madbeanpedals.com/forum/index.php?topic=33087.0


Libraries used:

Liquid Crystal
https://github.com/fmalpartida/New-LiquidCrystal

One Button
https://github.com/mathertel/OneButton
http://www.mathertel.de/Arduino/OneButtonLibrary.aspx
